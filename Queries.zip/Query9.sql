#Top Spending Customers
SELECT 
    c.CustomerKey, 
    c.Country,
    COUNT(DISTINCT s.OrderNumber) AS Total_Orders,
    SUM(s.Quantity * p.UnitPriceUSD) AS Total_Spending
FROM Sales s
JOIN Customers c ON s.CustomerKey = c.CustomerKey
JOIN Products p ON s.ProductKey = p.ProductKey
GROUP BY c.CustomerKey, c.Country
ORDER BY Total_Spending DESC
LIMIT 10;