	#Top and Low Performing Profucts
    
    SELECT 
    p.ProductName,
    p.Brand,
    SUM(s.Quantity) AS Total_Units_Sold,
    SUM(s.Quantity * p.UnitPriceUSD) AS Total_Revenue
FROM Sales s
JOIN Products p ON s.ProductKey = p.ProductKey
GROUP BY p.ProductName, p.Brand
ORDER BY Total_Revenue DESC
LIMIT 10;
    
SELECT 
    p.ProductName,
    p.Brand,
    SUM(s.Quantity) AS Total_Units_Sold,
    SUM(s.Quantity * p.UnitPriceUSD) AS Total_Revenue
FROM Sales s
JOIN Products p ON s.ProductKey = p.ProductKey
GROUP BY p.ProductName, p.Brand
ORDER BY Total_Revenue ASC
LIMIT 10;
    
    