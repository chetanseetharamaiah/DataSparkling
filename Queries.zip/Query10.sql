#Product  Category Performance  Over Time

SELECT 
    YEAR(s.OrderDate) AS Sales_Year,
    p.Category,
    SUM(s.Quantity * p.UnitPriceUSD) AS Total_Sales
FROM Sales s
JOIN Products p ON s.ProductKey = p.ProductKey
GROUP BY YEAR(s.OrderDate), p.Category
ORDER BY Sales_Year DESC, Total_Sales DESC;