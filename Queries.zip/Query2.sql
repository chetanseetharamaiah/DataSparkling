# Total Number of Orders Based on Age Group.
SELECT 
    CASE
        WHEN FLOOR(DATEDIFF(CURDATE(), c.Birthday) / 365.25) BETWEEN 1 AND 19 THEN '18+'
        WHEN FLOOR(DATEDIFF(CURDATE(), c.Birthday) / 365.25) BETWEEN 20 AND 29 THEN '20+'
        WHEN FLOOR(DATEDIFF(CURDATE(), c.Birthday) / 365.25) BETWEEN 30 AND 39 THEN '30+'
        WHEN FLOOR(DATEDIFF(CURDATE(), c.Birthday) / 365.25) BETWEEN 40 AND 49 THEN '40+'
        WHEN FLOOR(DATEDIFF(CURDATE(), c.Birthday) / 365.25) BETWEEN 50 AND 59 THEN '50+'
        WHEN FLOOR(DATEDIFF(CURDATE(), c.Birthday) / 365.25) BETWEEN 60 AND 69 THEN '60+'
        WHEN FLOOR(DATEDIFF(CURDATE(), c.Birthday) / 365.25) BETWEEN 70 AND 79 THEN '70+'
        ELSE '80+'
    END AS AgeGroup,
    COUNT(DISTINCT c.CustomerKey) AS Count_of_age_group,
    CASE 
        WHEN COUNT(DISTINCT s.OrderNumber) = 0 THEN 'No Orders'
        ELSE COUNT(DISTINCT s.OrderNumber)
    END AS TotalOrderNumbers
    
    
FROM 
    customers c
INNER JOIN 
    sales s ON c.CustomerKey = s.CustomerKey
GROUP BY 
    CASE
        WHEN FLOOR(DATEDIFF(CURDATE(), c.Birthday) / 365.25) BETWEEN 1 AND 19 THEN '18+'
        WHEN FLOOR(DATEDIFF(CURDATE(), c.Birthday) / 365.25) BETWEEN 20 AND 29 THEN '20+'
        WHEN FLOOR(DATEDIFF(CURDATE(), c.Birthday) / 365.25) BETWEEN 30 AND 39 THEN '30+'
        WHEN FLOOR(DATEDIFF(CURDATE(), c.Birthday) / 365.25) BETWEEN 40 AND 49 THEN '40+'
        WHEN FLOOR(DATEDIFF(CURDATE(), c.Birthday) / 365.25) BETWEEN 50 AND 59 THEN '50+'
        WHEN FLOOR(DATEDIFF(CURDATE(), c.Birthday) / 365.25) BETWEEN 60 AND 69 THEN '60+'
        WHEN FLOOR(DATEDIFF(CURDATE(), c.Birthday) / 365.25) BETWEEN 70 AND 79 THEN '70+'
        ELSE '80+'
    END
ORDER BY 
    AgeGroup;