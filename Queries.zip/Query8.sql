# Store Wise Analysis
SELECT 
    s.StoreKey,
    st.State,
    st.Country,
    COUNT(DISTINCT s.OrderNumber) AS Total_Orders,
    COUNT(DISTINCT s.CustomerKey) AS Total_Customers,
    SUM(s.Quantity * p.UnitPriceUSD) AS Total_Sales,
    SUM(s.Quantity * (p.UnitPriceUSD - p.UnitCostUSD)) AS Total_Profit
FROM Sales s
JOIN Products p ON s.ProductKey = p.ProductKey
JOIN Stores st ON s.StoreKey = st.StoreKey
GROUP BY s.StoreKey, st.State, st.Country
ORDER BY Total_Sales DESC;