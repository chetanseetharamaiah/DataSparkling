# Fetcing totalnumber of Orders, Male & Femal Customers,Orders.
# Total Customers Based on Country and Total Orders Based on Country
SELECT 
	(SELECT COUNT(DISTINCT OrderNumber) FROM Sales) AS Total_Orders,
    (SELECT COUNT(*) FROM Customers WHERE Gender = 'Male') AS Male_Customers,
    (SELECT COUNT(*) FROM Customers WHERE Gender = 'Female') AS Female_Customers,
    (SELECT COUNT(DISTINCT s.OrderNumber) FROM Customers c 
        JOIN Sales s ON c.CustomerKey = s.CustomerKey 
        WHERE c.Gender = 'Male') AS Orders_by_Male,
    (SELECT COUNT(DISTINCT s.OrderNumber) FROM Customers c 
        JOIN Sales s ON c.CustomerKey = s.CustomerKey 
        WHERE c.Gender = 'Female') AS Orders_by_Female;
	
SELECT 
	c.Country, 
	COUNT(DISTINCT c.CustomerKey) AS Total_Customers,
    COUNT(DISTINCT s.OrderNumber) AS Country_wise_Total_Order
FROM Customers c
LEFT JOIN sales s ON  c.CustomerKey = s.CustomerKey
GROUP BY c.Country;

	

