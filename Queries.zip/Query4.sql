# Fetching Total Cost, Total Sales, Total Profit based on Currency Code, Country, Catergory and Brand.

SELECT 
    s.CurrencyCode,
    SUM(s.Quantity * p.UnitPriceUSD) AS Total_Sales,
    SUM(s.Quantity * p.UnitCostUSD) AS Total_Cost,
    SUM(s.Quantity * (p.UnitPriceUSD - p.UnitCostUSD)) AS Total_Profit
FROM Sales s
JOIN Customers c ON s.CustomerKey = c.CustomerKey
JOIN Products p ON s.ProductKey = p.ProductKey
GROUP BY  s.CurrencyCode
ORDER BY Total_Profit DESC;


SELECT 
    c.Country,
    SUM(s.Quantity * p.UnitPriceUSD) AS Total_Sales,
    SUM(s.Quantity * p.UnitCostUSD) AS Total_Cost,
    SUM(s.Quantity * (p.UnitPriceUSD - p.UnitCostUSD)) AS Total_Profit
FROM Sales s
JOIN Customers c ON s.CustomerKey = c.CustomerKey
JOIN Products p ON s.ProductKey = p.ProductKey
GROUP BY c.Country
ORDER BY Total_Profit DESC;

SELECT 
    p.Category,
    SUM(s.Quantity * p.UnitPriceUSD) AS Total_Sales,
    SUM(s.Quantity * p.UnitCostUSD) AS Total_Cost,
    SUM(s.Quantity * (p.UnitPriceUSD - p.UnitCostUSD)) AS Total_Profit
FROM Sales s
JOIN Products p ON s.ProductKey = p.ProductKey
GROUP BY  p.Category
ORDER BY Total_Profit DESC;

SELECT 
    p.Brand,
    SUM(s.Quantity * p.UnitPriceUSD) AS Total_Sales,
    SUM(s.Quantity * p.UnitCostUSD) AS Total_Cost,
    SUM(s.Quantity * (p.UnitPriceUSD - p.UnitCostUSD)) AS Total_Profit
FROM Sales s
JOIN Products p ON s.ProductKey = p.ProductKey
GROUP BY  p.Brand
ORDER BY Total_Profit DESC;