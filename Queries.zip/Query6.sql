#Purchase Frequency Based on Total Order, Year, Brand, Colour,Country
SELECT 
    COUNT(DISTINCT s.OrderNumber) AS Total_Orders,
    COUNT(DISTINCT s.CustomerKey) AS Total_Customers,
    COUNT(DISTINCT s.OrderNumber) * 1.0 / COUNT(DISTINCT s.CustomerKey) AS Purchase_Frequency
FROM Sales s;

#Purchase Frequency by Purchase Year
SELECT 
    YEAR(s.OrderDate) AS Purchase_Year,
    COUNT(DISTINCT s.OrderNumber) AS Total_Orders,
    COUNT(DISTINCT s.CustomerKey) AS Total_Customers,
    COUNT(DISTINCT s.OrderNumber) * 1.0 / COUNT(DISTINCT s.CustomerKey) AS Purchase_Frequency
FROM Sales s
GROUP BY YEAR(s.OrderDate);

#Purchase Frequency by Brand
SELECT 
    p.Brand,
    COUNT(DISTINCT s.OrderNumber) AS Total_Orders,
    COUNT(DISTINCT s.CustomerKey) AS Total_Customers,
    COUNT(DISTINCT s.OrderNumber) * 1.0 / COUNT(DISTINCT s.CustomerKey) AS Purchase_Frequency
FROM Sales s
JOIN Products p ON s.ProductKey = p.ProductKey
GROUP BY p.Brand;

#Purchase Frequency by Colour
SELECT 
    p.Color,
    COUNT(DISTINCT s.OrderNumber) AS Total_Orders,
    COUNT(DISTINCT s.CustomerKey) AS Total_Customers,
    COUNT(DISTINCT s.OrderNumber) * 1.0 / COUNT(DISTINCT s.CustomerKey) AS Purchase_Frequency
FROM Sales s
JOIN Products p ON s.ProductKey = p.ProductKey
GROUP BY p.Color;

#Purchase Frequency by Country
SELECT 
    c.Country,
    COUNT(DISTINCT s.OrderNumber) AS Total_Orders,
    COUNT(DISTINCT s.CustomerKey) AS Total_Customers,
    COUNT(DISTINCT s.OrderNumber) * 1.0 / COUNT(DISTINCT s.CustomerKey) AS Purchase_Frequency
FROM Sales s
JOIN Customers c ON s.CustomerKey = c.CustomerKey
GROUP BY c.Country;