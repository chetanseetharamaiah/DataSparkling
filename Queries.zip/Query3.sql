# Fetching the total number of Ordernumbers based on LineItem.
WITH OrderLineItemTotals AS (
    SELECT 
        OrderNumber, 
        SUM(LineItem) AS TotalLineItem,
        COUNT(LineItem) AS LineItemCount
    FROM 
        Sales
    GROUP BY 
        OrderNumber
)

-- Get count of orders for each specific LineItem total
SELECT 
    TotalLineItem AS LineItem,
    COUNT(OrderNumber) AS OrderCount
FROM 
    OrderLineItemTotals
#WHERE 
    #TotalLineItem = LineItemCount -- Only include orders where TotalLineItem matches LineItemCount
GROUP BY 
    TotalLineItem
ORDER BY 
    LineItem;