# Calculating Average Order Value based on Purchasing Year, Brand and Country.
SELECT 
	SUM(s.Quantity * p.UnitPriceUSD) AS Total_Revenu,
    COUNT(DISTINCT s.OrderNumber) AS Total_OrderNumber,
    SUM(s.Quantity * p.UnitPriceUSD) * 1.0/COUNT(DISTINCT s.OrderNumber) AS Average_Order_Value
FROM Sales s
JOIN products p ON s.ProductKey = p.ProductKey;
 
SELECT
	YEAR(s.OrderDate) AS Purchase_Year,
    SUM(s.Quantity * p.UnitPriceUSD) AS Total_Revenu,
    COUNT(DISTINCT s.OrderNumber) AS Total_OrderNumber,
    SUM(s.Quantity * p.UnitPriceUSD) * 1.0/COUNT(DISTINCT s.OrderNumber) AS Average_Order_Value
FROM sales s
JOIN Products p ON s.ProductKey = p.ProductKey
GROUP BY YEAR(s.OrderDate);

SELECT
	p.Brand,
    SUM(s.Quantity * p.UnitPriceUSD) AS Total_Revenu,
    COUNT(DISTINCT s.OrderNumber) AS Total_OrderNumber,
    SUM(s.Quantity * p.UnitPriceUSD) * 1.0/COUNT(DISTINCT s.OrderNumber) AS Average_Order_Value
FROM sales s
JOIN Products p ON s.ProductKey = p.ProductKey
GROUP BY p.Brand;

SELECT
	c.Country,
    SUM(s.Quantity * p.UnitPriceUSD) AS Total_Revenu,
    COUNT(DISTINCT s.OrderNumber) AS Total_OrderNumber,
    SUM(s.Quantity * p.UnitPriceUSD) * 1.0/COUNT(DISTINCT s.OrderNumber) AS Average_Order_Value
FROM sales s
JOIN Customers c ON s.CustomerKey = c.CustomerKey
JOIN Products p ON s.ProductKey = p.ProductKey
GROUP BY c.Country;